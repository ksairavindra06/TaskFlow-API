package com.sairavindra.taskflow.model;

public enum TaskPriority {
    LOW,
    MEDIUM,
    HIGH
}
