package com.sairavindra.taskflow.model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}
