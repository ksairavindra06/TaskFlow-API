package com.sairavindra.taskflow.service;

import com.sairavindra.taskflow.dto.TaskRequest;
import com.sairavindra.taskflow.exception.TaskNotFoundException;
import com.sairavindra.taskflow.model.Task;
import com.sairavindra.taskflow.model.TaskPriority;
import com.sairavindra.taskflow.model.TaskStatus;
import com.sairavindra.taskflow.repository.TaskRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskServiceTest {

    @Mock
    private TaskRepository taskRepository;

    @InjectMocks
    private TaskService taskService;

    private Task sampleTask;

    @BeforeEach
    void setUp() {
        sampleTask = new Task();
        sampleTask.setId(1L);
        sampleTask.setTitle("Write unit tests");
        sampleTask.setDescription("Cover the service layer");
        sampleTask.setStatus(TaskStatus.TODO);
        sampleTask.setPriority(TaskPriority.HIGH);
    }

    @Test
    void getTaskById_returnsTask_whenTaskExists() {
        when(taskRepository.findById(1L)).thenReturn(Optional.of(sampleTask));

        Task result = taskService.getTaskById(1L);

        assertThat(result.getTitle()).isEqualTo("Write unit tests");
        verify(taskRepository, times(1)).findById(1L);
    }

    @Test
    void getTaskById_throwsException_whenTaskDoesNotExist() {
        when(taskRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> taskService.getTaskById(99L))
                .isInstanceOf(TaskNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void createTask_savesAndReturnsTask() {
        TaskRequest request = new TaskRequest();
        request.setTitle("Deploy to staging");
        request.setDescription("Push the latest build");
        request.setPriority(TaskPriority.MEDIUM);

        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> {
            Task t = invocation.getArgument(0);
            t.setId(2L);
            return t;
        });

        Task result = taskService.createTask(request);

        assertThat(result.getId()).isEqualTo(2L);
        assertThat(result.getTitle()).isEqualTo("Deploy to staging");
        assertThat(result.getStatus()).isEqualTo(TaskStatus.TODO); // default
        verify(taskRepository, times(1)).save(any(Task.class));
    }

    @Test
    void deleteTask_removesTask_whenTaskExists() {
        when(taskRepository.findById(1L)).thenReturn(Optional.of(sampleTask));

        taskService.deleteTask(1L);

        verify(taskRepository, times(1)).delete(sampleTask);
    }

    @Test
    void getTasksByStatus_returnsFilteredList() {
        when(taskRepository.findByStatus(TaskStatus.TODO)).thenReturn(List.of(sampleTask));

        List<Task> result = taskService.getTasksByStatus(TaskStatus.TODO);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo(TaskStatus.TODO);
    }
}
